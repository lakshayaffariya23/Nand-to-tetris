"""Two-pass Hack assembler for Lakshay's Nand to Tetris capstone.
Usage: python assembler.py Box.asm
"""

import re
import sys

PREDEFINED = {
    "SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
    "SCREEN": 16384, "KBD": 24576,
}
for i in range(16):
    PREDEFINED[f"R{i}"] = i

DEST = {
    "": "000", "M": "001", "D": "010", "MD": "011",
    "A": "100", "AM": "101", "AD": "110", "AMD": "111",
}
JUMP = {
    "": "000", "JGT": "001", "JEQ": "010", "JGE": "011",
    "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111",
}
COMP = {
    "0": "0101010", "1": "0111111", "-1": "0111010",
    "D": "0001100", "A": "0110000", "M": "1110000",
    "!D": "0001101", "!A": "0110001", "!M": "1110001",
    "-D": "0001111", "-A": "0110011", "-M": "1110011",
    "D+1": "0011111", "A+1": "0110111", "M+1": "1110111",
    "D-1": "0001110", "A-1": "0110010", "M-1": "1110010",
    "D+A": "0000010", "D+M": "1000010",
    "D-A": "0010011", "D-M": "1010011",
    "A-D": "0000111", "M-D": "1000111",
    "D&A": "0000000", "D&M": "1000000",
    "D|A": "0010101", "D|M": "1010101",
}

SYMBOL_RE = re.compile(r"^[A-Za-z_.$:][A-Za-z0-9_.$:]*$")


def clean_lines(source):
    """Return (original_line_number, cleaned_instruction) pairs."""
    cleaned = []
    for line_number, raw_line in enumerate(source.splitlines(), start=1):
        line = raw_line.split("//", 1)[0].strip()
        if line:
            cleaned.append((line_number, line))
    return cleaned


def assemble(source):
    lines = clean_lines(source)
    symbols = dict(PREDEFINED)
    instructions = []

    # Pass 1: resolve labels to ROM addresses.
    rom_address = 0
    for line_number, line in lines:
        if line.startswith("(") and line.endswith(")"):
            label = line[1:-1].strip()
            if not SYMBOL_RE.fullmatch(label):
                raise ValueError(f"Line {line_number}: invalid label")
            if label in symbols:
                print(f"Line {line_number}: warning: duplicate label '{label}'")
            else:
                symbols[label] = rom_address
        else:
            instructions.append((line_number, line))
            rom_address += 1

    # Pass 2: translate instructions; allocate variables from RAM address 16.
    next_variable_address = 16
    machine_code = []

    for line_number, line in instructions:
        try:
            if line.startswith("@"):
                symbol_or_number = line[1:].strip()
                if symbol_or_number.isdigit():
                    address = int(symbol_or_number)
                else:
                    if not SYMBOL_RE.fullmatch(symbol_or_number):
                        raise ValueError("invalid A-instruction")
                    if symbol_or_number not in symbols:
                        symbols[symbol_or_number] = next_variable_address
                        next_variable_address += 1
                    address = symbols[symbol_or_number]

                if not 0 <= address <= 32767:
                    raise ValueError("A-instruction address must be between 0 and 32767")
                machine_code.append(format(address, "016b"))
            else:
                if line.count("=") > 1 or line.count(";") > 1:
                    raise ValueError("invalid C-instruction")

                if ";" in line:
                    left_part, jump = line.split(";", 1)
                else:
                    left_part, jump = line, ""

                if "=" in left_part:
                    dest, comp = left_part.split("=", 1)
                else:
                    dest, comp = "", left_part

                dest = dest.strip()
                comp = comp.strip()
                jump = jump.strip()

                if dest not in DEST or comp not in COMP or jump not in JUMP:
                    raise ValueError("invalid C-instruction")
                machine_code.append("111" + COMP[comp] + DEST[dest] + JUMP[jump])

        except ValueError as error:
            message = str(error)
            if message.startswith("Line "):
                raise
            raise ValueError(f"Line {line_number}: {message}") from error

    return machine_code, symbols


def main():
    if len(sys.argv) != 2:
        print("Usage: python assembler.py input.asm")
        return 2

    input_path = sys.argv[1]
    try:
        with open(input_path, "r", encoding="utf-8") as source_file:
            source = source_file.read()

        machine_code, _symbols = assemble(source)
        output_path = input_path.rsplit(".", 1)[0] + ".hack"
        with open(output_path, "w", encoding="utf-8") as output_file:
            output_file.write("\n".join(machine_code) + "\n")

        print(f"Created {output_path} ({len(machine_code)} instructions)")
        return 0
    except (OSError, ValueError) as error:
        print(error)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
