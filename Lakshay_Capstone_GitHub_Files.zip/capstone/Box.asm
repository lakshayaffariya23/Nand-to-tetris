// Lakshay | Roll No. 2501010328 | K = 28
// Starts at row 28; height 20 rows; width 16 pixels (one screen word).
// A pressed key draws black; releasing the key clears the same area.

(START)
    @KBD
    D=M
    @DRAW
    D;JNE

// No key pressed: clear the 20 screen words.
(CLEAR)
    @SCREEN
    D=A
    @896
    D=D+A
    @PTR
    M=D
    @20
    D=A
    @COUNT
    M=D

(CLEAR_LOOP)
    @PTR
    A=M
    M=0
    @32
    D=A
    @PTR
    M=D+M
    @COUNT
    MD=M-1
    @CLEAR_LOOP
    D;JGT
    @START
    0;JMP

// Key pressed: draw 20 black screen words.
(DRAW)
    @SCREEN
    D=A
    @896
    D=D+A
    @PTR
    M=D
    @20
    D=A
    @COUNT
    M=D

(DRAW_LOOP)
    @PTR
    A=M
    M=-1
    @32
    D=A
    @PTR
    M=D+M
    @COUNT
    MD=M-1
    @DRAW_LOOP
    D;JGT
    @START
    0;JMP
